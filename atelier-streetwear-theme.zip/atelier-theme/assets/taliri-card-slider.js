/* TALIRI — card media slider helpers
   1. Transparent-header state: .taliri-over-hero while the pinned navbar
      still covers the hero banner (home) / product gallery (PDP)
   2. Mouse drag-to-scroll (touch and trackpad already scroll natively)
   3. Active-dot sync on scroll */
(function () {
  var header = document.querySelector(
    '.template-index .section-header, .template-product .section-header'
  );
  if (!header) return;
  var ref =
    document.querySelector('.product__media-wrapper') ||
    document.querySelector('#MainContent .shopify-section');
  if (!ref) return;

  var ticking = false;
  function update() {
    ticking = false;
    var overHero = ref.getBoundingClientRect().bottom >= header.getBoundingClientRect().bottom;
    header.classList.toggle('taliri-over-hero', overHero);
  }
  window.addEventListener(
    'scroll',
    function () {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    },
    { passive: true }
  );
  window.addEventListener('resize', update);
  update();
})();

/* product page: buy buttons become a sticky bottom bar (add-to-cart + size
   dropdown) whenever the in-page buttons are out of view. A stable-height
   anchor reserves their space and is what the observer watches, so pinning
   the buttons never resizes the observed box → smooth, no threshold flicker. */
(function () {
  var infoWrapper = document.querySelector('.product__info-wrapper');
  var buttons = infoWrapper && infoWrapper.querySelector('.product-form__buttons');
  if (!buttons || !('IntersectionObserver' in window)) return;

  // stable-height anchor wrapping the buttons
  var anchor = document.createElement('div');
  anchor.className = 'taliri-buy-anchor';
  buttons.parentNode.insertBefore(anchor, buttons);
  anchor.appendChild(buttons);

  function reserve() {
    if (!buttons.classList.contains('taliri-buy-sticky')) {
      anchor.style.minHeight = buttons.offsetHeight + 'px';
    }
  }
  reserve();
  window.addEventListener('load', reserve);
  // wallet button renders async; keep the reserved height in sync
  if ('ResizeObserver' in window) {
    new ResizeObserver(reserve).observe(buttons);
  }

  // sticky controls row (size + colourway dropdowns) pinned above the CTA
  var stickyControls = document.createElement('div');
  stickyControls.className = 'taliri-sticky-controls';
  buttons.insertBefore(stickyControls, buttons.firstChild);
  buildSizeDropdown(stickyControls, infoWrapper);
  buildColorDropdown(stickyControls);

  // sticky bar: current price shown inside the add-to-cart button (hidden by
  // CSS while the buttons are in their normal in-page spot). Appended as a
  // SIBLING of Dawn's label span — Dawn rewrites that span's textContent on
  // variant change, which would wipe a nested node.
  var submitBtn = buttons.querySelector('.product-form__submit');
  if (submitBtn) {
    var priceSpan = document.createElement('span');
    priceSpan.className = 'taliri-sticky-price';
    submitBtn.appendChild(priceSpan);
    var updatePrice = function () {
      var box = infoWrapper.querySelector('.price');
      var el =
        box &&
        (box.classList.contains('price--on-sale')
          ? box.querySelector('.price__sale .price-item--sale')
          : box.querySelector('.price__regular .price-item--regular'));
      var t = el ? el.textContent.trim() : '';
      priceSpan.textContent = '';
      if (t) {
        var sep = document.createElement('span');
      sep.className = 'taliri-sticky-price__sep';
      sep.textContent = ' · ';
      priceSpan.appendChild(sep);
        if (box.classList.contains('price--on-sale')) {
          var was = box.querySelector('.price__sale s.price-item--regular, .price__sale .price-item--regular');
          if (was && was.textContent.trim()) {
            var st = document.createElement('s');
            st.className = 'taliri-sticky-price__was';
            st.textContent = was.textContent.trim();
            priceSpan.appendChild(st);
            priceSpan.appendChild(document.createTextNode(' '));
          }
        }
        priceSpan.appendChild(document.createTextNode(t));
      }
    };
    updatePrice();
    window.addEventListener('load', updatePrice);
    // variant change re-renders the price block async; re-read after it lands
    infoWrapper.addEventListener('change', function () {
      setTimeout(updatePrice, 300);
      setTimeout(updatePrice, 900);
    });
  }

  // Toggle the sticky bar from scroll position with a HYSTERESIS band: a
  // single-threshold observer re-fires on tiny scrolls at the boundary, which
  // restarts the slide-in animation (reads as flicker/jank, and can leave the
  // bar stuck hidden). Two separate show/hide thresholds create a dead zone so
  // it settles cleanly. Sticky is shown only while the in-page add-to-cart is
  // off screen — the size selector staying visible doesn't matter, since the
  // anchor wraps the buttons alone.
  var isSticky = false;
  var ticking2 = false;
  function evaluateSticky() {
    ticking2 = false;
    var rect = anchor.getBoundingClientRect();
    var vh = window.innerHeight || document.documentElement.clientHeight;
    // show the sticky bar unless the real add-to-cart is FULLY in view — a
    // button cut off at the top or bottom of the fold isn't usable, so the
    // bar should be up (this is why it must show on load: the button sits
    // below the gallery, off-screen). Two thresholds = hysteresis, no flicker.
    var notUsable = rect.bottom > vh - 4 || rect.top < 4;      // any edge clipped
    var fullyVisible = rect.top >= 12 && rect.bottom <= vh - 12; // comfortably in view
    if (!isSticky && notUsable) {
      isSticky = true;
      buttons.classList.add('taliri-buy-sticky');
    } else if (isSticky && fullyVisible) {
      isSticky = false;
      buttons.classList.remove('taliri-buy-sticky');
    }
  }
  window.addEventListener(
    'scroll',
    function () {
      if (!ticking2) {
        ticking2 = true;
        requestAnimationFrame(evaluateSticky);
      }
    },
    { passive: true }
  );
  window.addEventListener('resize', evaluateSticky);
  window.addEventListener('load', evaluateSticky);
  evaluateSticky();

  function buildSizeDropdown(container, wrapper) {
    var vs = wrapper.querySelector('variant-selects');
    if (!vs) return;
    var radios = vs.querySelectorAll('input[type="radio"]');
    if (radios.length < 2) return;
    // single-option (Size) products only; skip multi-option combos
    var names = {};
    [].forEach.call(radios, function (r) {
      names[r.name] = 1;
    });
    if (Object.keys(names).length > 1) return;

    var dd = document.createElement('details');
    dd.className = 'taliri-size-dd';
    var toggle = document.createElement('summary');
    toggle.className = 'taliri-size-dd__toggle';
    var label = document.createElement('span');
    label.className = 'taliri-size-dd__labelwrap';
    var prefix = document.createElement('span');
    prefix.className = 'taliri-size-dd__prefix';
    prefix.textContent = (document.documentElement.lang || '').indexOf('fr') === 0 ? 'Taille' : 'Size';
    var value = document.createElement('span');
    value.className = 'taliri-size-dd__value';
    label.appendChild(prefix);
    label.appendChild(value);
    toggle.appendChild(label);
    dd.appendChild(toggle);
    var panel = document.createElement('div');
    panel.className = 'taliri-size-dd__panel';
    dd.appendChild(panel);

    function liveChecked() {
      var c = wrapper.querySelector('variant-selects input[type="radio"]:checked');
      return c ? c.value : '';
    }
    function liveByValue(v) {
      return wrapper.querySelector(
        'variant-selects input[type="radio"][value="' + (window.CSS && CSS.escape ? CSS.escape(v) : v) + '"]'
      );
    }
    function syncLabel() {
      var cur = liveChecked();
      value.textContent = cur || '';
      [].forEach.call(panel.children, function (b) {
        var v = b.getAttribute('data-value');
        b.classList.toggle('is-selected', v === cur);
        var live = liveByValue(v);
        b.classList.toggle('is-soldout', !!(live && live.disabled));
      });
    }

    [].forEach.call(radios, function (radio) {
      var value = radio.value;
      var opt = document.createElement('button');
      opt.type = 'button';
      opt.className = 'taliri-size-dd__opt';
      opt.setAttribute('data-value', value);
      opt.textContent = value;
      opt.addEventListener('click', function () {
        var live = liveByValue(value); // re-query: Dawn re-renders the radios
        if (live && !live.checked) {
          live.checked = true;
          live.dispatchEvent(new Event('change', { bubbles: true }));
        }
        dd.open = false;
        syncLabel();
      });
      panel.appendChild(opt);
    });

    container.appendChild(dd);
    syncLabel();

    // reflect size changes made from the in-page selector (event delegation
    // survives Dawn re-rendering the radios)
    wrapper.addEventListener('change', function (e) {
      if (e.target && e.target.name && /size|taille/i.test(e.target.name)) syncLabel();
    });

    document.addEventListener('click', function (e) {
      if (dd.open && !dd.contains(e.target)) dd.open = false;
    });
  }

  // colourway dropdown: built from the linked-colourway thumbnails
  // (.taliri-cl, fed by the custom.color_variants metafield); picking another
  // colourway navigates to its product page.
  function buildColorDropdown(container) {
    var row = document.querySelector('.taliri-cl__row');
    if (!row) return;
    var items = row.querySelectorAll('.taliri-cl__item');
    if (items.length < 2) return;

    var dd = document.createElement('details');
    dd.className = 'taliri-size-dd taliri-color-dd';
    var toggle = document.createElement('summary');
    toggle.className = 'taliri-size-dd__toggle';
    var label = document.createElement('span');
    label.className = 'taliri-size-dd__labelwrap';
    var prefix = document.createElement('span');
    prefix.className = 'taliri-size-dd__prefix';
    prefix.textContent = (document.documentElement.lang || '').indexOf('fr') === 0 ? 'Couleur' : 'Color';
    var value = document.createElement('span');
    value.className = 'taliri-size-dd__value';
    label.appendChild(prefix);
    label.appendChild(value);
    toggle.appendChild(label);
    dd.appendChild(toggle);
    var panel = document.createElement('div');
    panel.className = 'taliri-size-dd__panel';
    dd.appendChild(panel);

    [].forEach.call(items, function (it) {
      var title = it.getAttribute('title') || '';
      var isCurrent = it.classList.contains('is-current');
      if (isCurrent) value.textContent = title;
      var opt = document.createElement('button');
      opt.type = 'button';
      opt.className = 'taliri-size-dd__opt' + (isCurrent ? ' is-selected' : '');
      opt.textContent = title;
      opt.addEventListener('click', function () {
        dd.open = false;
        var href = it.getAttribute('href');
        if (!isCurrent && href) window.location.href = href;
      });
      panel.appendChild(opt);
    });
    if (!value.textContent) value.textContent = items[0].getAttribute('title') || '';

    container.insertBefore(dd, container.firstChild);
    document.addEventListener('click', function (e) {
      if (dd.open && !dd.contains(e.target)) dd.open = false;
    });
  }
})();

/* PDP mobile: dot indicators overlaid on the gallery, synced with the swipe */
(function () {
  var slider = document.querySelector('.product__media-wrapper .product__media-list');
  if (!slider) return;
  var items = slider.querySelectorAll('.product__media-item');
  if (items.length < 2) return;

  var host = slider.closest('slider-component') || slider.parentElement;
  var dots = document.createElement('div');
  dots.className = 'taliri-pdp-dots';
  dots.setAttribute('aria-hidden', 'true');
  for (var i = 0; i < items.length; i++) {
    var dot = document.createElement('span');
    dot.className = 'taliri-pdp-dots__dot' + (i === 0 ? ' is-active' : '');
    dots.appendChild(dot);
  }
  host.appendChild(dots);

  var ticking = false;
  slider.addEventListener(
    'scroll',
    function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        ticking = false;
        var pos = slider.scrollLeft;
        var best = 0;
        var bestDist = Infinity;
        for (var i = 0; i < items.length; i++) {
          var dist = Math.abs(items[i].offsetLeft - pos);
          if (dist < bestDist) {
            bestDist = dist;
            best = i;
          }
        }
        for (var j = 0; j < dots.children.length; j++) {
          dots.children[j].classList.toggle('is-active', j === best);
        }
      });
    },
    { passive: true }
  );
})();

(function () {
  var slider = null;
  var startX = 0;
  var startScroll = 0;
  var dragging = false;

  document.addEventListener('pointerdown', function (e) {
    if (e.pointerType !== 'mouse' || e.button !== 0) return;
    var s = e.target.closest && e.target.closest('.card-media-slider');
    if (!s || s.scrollWidth <= s.clientWidth) return;
    slider = s;
    startX = e.clientX;
    startScroll = s.scrollLeft;
    dragging = false;
  });

  document.addEventListener('pointermove', function (e) {
    if (!slider) return;
    var dx = e.clientX - startX;
    if (!dragging && Math.abs(dx) > 5) {
      dragging = true;
      slider.style.scrollSnapType = 'none';
    }
    if (dragging) {
      slider.scrollLeft = startScroll - dx;
      e.preventDefault();
    }
  });

  function endDrag() {
    if (!slider) return;
    if (dragging) {
      var s = slider;
      var w = s.clientWidth || 1;
      var target = Math.max(0, Math.min(Math.round(s.scrollLeft / w) * w, s.scrollWidth - w));
      s.style.scrollSnapType = '';
      s.scrollTo({ left: target, behavior: 'smooth' });
      s.setAttribute('data-dragged', 'true');
      setTimeout(function () {
        s.removeAttribute('data-dragged');
      }, 0);
    }
    slider = null;
    dragging = false;
  }

  document.addEventListener('pointerup', endDrag);
  document.addEventListener('pointercancel', endDrag);

  // a drag must not count as a click on the slide link
  document.addEventListener(
    'click',
    function (e) {
      var s = e.target.closest && e.target.closest('.card-media-slider');
      if (s && s.hasAttribute('data-dragged')) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true
  );

  // active dot follows the visible slide
  document.addEventListener(
    'scroll',
    function (e) {
      var s = e.target;
      if (!s.classList || !s.classList.contains('card-media-slider')) return;
      var media = s.closest('.media');
      var dots = media && media.parentElement.querySelectorAll('.card-media-dots__dot');
      if (!dots || !dots.length) return;
      var index = Math.round(s.scrollLeft / (s.clientWidth || 1));
      for (var i = 0; i < dots.length; i++) {
        dots[i].classList.toggle('is-active', i === index);
      }
    },
    true
  );
})();

/* mobile: tapping a card "+" opens a bottom size sheet (instead of the full
   quick-add modal); picking a size adds it to cart and opens the cart drawer */
(function () {
  var mqMobile = window.matchMedia('(max-width: 749px)');
  var isFr = ((window.Shopify && Shopify.locale) || document.documentElement.lang || 'en').toLowerCase().indexOf('fr') === 0;
  var T = {
    label: isFr ? 'Choisir la taille' : 'Choose your size',
    added: isFr ? 'Ajouté au panier' : 'Added to cart'
  };
  var sheet, sheetTitle, sheetSizes;

  function build() {
    sheet = document.createElement('div');
    sheet.className = 'taliri-qa-sheet';
    sheet.hidden = true;
    sheet.innerHTML =
      '<div class="taliri-qa-sheet__backdrop"></div>' +
      '<div class="taliri-qa-sheet__panel" role="dialog" aria-modal="true">' +
        '<button type="button" class="taliri-qa-sheet__close" aria-label="Close">&times;</button>' +
        '<div class="taliri-qa-sheet__title"></div>' +
        '<div class="taliri-qa-sheet__label">' + T.label + '</div>' +
        '<div class="taliri-qa-sheet__sizes"></div>' +
      '</div>';
    document.body.appendChild(sheet);
    sheetTitle = sheet.querySelector('.taliri-qa-sheet__title');
    sheetSizes = sheet.querySelector('.taliri-qa-sheet__sizes');
    sheet.querySelector('.taliri-qa-sheet__backdrop').addEventListener('click', close);
    sheet.querySelector('.taliri-qa-sheet__close').addEventListener('click', close);
  }

  function open(data) {
    if (!sheet) build();
    sheetTitle.textContent = data.title || '';
    sheetSizes.innerHTML = '';
    (data.variants || []).forEach(function (v) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'taliri-qa-sheet__size' + (v.available ? '' : ' is-soldout');
      b.textContent = v.size;
      if (!v.available) b.disabled = true;
      else b.addEventListener('click', function () { add(v.id, b); });
      sheetSizes.appendChild(b);
    });
    sheet.hidden = false;
    requestAnimationFrame(function () { sheet.classList.add('is-open'); });
  }

  function close() {
    if (!sheet) return;
    sheet.classList.remove('is-open');
    setTimeout(function () { sheet.hidden = true; }, 320);
  }

  function add(id, btn) {
    btn.classList.add('is-loading');
    var drawer = document.querySelector('cart-drawer');
    var sections = drawer && drawer.getSectionsToRender ? drawer.getSectionsToRender().map(function (s) { return s.id; }) : [];
    var root = (window.Shopify && Shopify.routes && Shopify.routes.root) || '/';
    fetch(root + 'cart/add.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ items: [{ id: id, quantity: 1 }], sections: sections, sections_url: window.location.pathname })
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        btn.classList.remove('is-loading');
        if (res && res.status) { btn.disabled = true; btn.classList.add('is-soldout'); return; }
        close();
        if (drawer && typeof drawer.renderContents === 'function') {
          drawer.classList.remove('is-empty');
          drawer.renderContents(res);
        } else {
          window.location.href = root + 'cart';
        }
      })
      .catch(function () { btn.classList.remove('is-loading'); });
  }

  document.addEventListener(
    'click',
    function (e) {
      if (!mqMobile.matches) return;
      var btn = e.target.closest && e.target.closest('.quick-add--overlay .quick-add__submit');
      if (!btn) return;
      var card = btn.closest('.card-wrapper') || btn.closest('.card');
      var dataEl = card && card.querySelector('.taliri-qa-data');
      if (!dataEl) return; // single-variant card → let Dawn add directly
      e.preventDefault();
      e.stopPropagation();
      try { open(JSON.parse(dataEl.textContent)); } catch (err) {}
    },
    true
  );

  // "Complete the look": the round "+" opens the bottom size sheet for the
  // paired product (multi-variant), or adds straight to cart (single variant).
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.taliri-ctl__add, .taliri-cart-suggest__add');
    if (!b || b.disabled || b.classList.contains('is-loading')) return;
    var card = b.closest('.taliri-ctl__card, .taliri-cart-suggest__card');
    var dataEl = card && card.querySelector('.taliri-qa-data');
    if (dataEl) {
      try { open(JSON.parse(dataEl.textContent)); } catch (err) {}
      return;
    }
    var id = parseInt(b.getAttribute('data-variant-id'), 10);
    if (id) add(id, b);
  });
})();


/* product description: clamp to 3 lines, expandable with a see-more toggle
   (only added when the text actually overflows the clamp) */
(function () {
  var desc = document.querySelector('.template-product .product__description');
  if (!desc) return;
  desc.classList.add('taliri-clamped');
  var fr = (document.documentElement.lang || '').indexOf('fr') === 0;
  function overflows() {
    return desc.scrollHeight > desc.clientHeight + 2;
  }
  function init() {
    if (!overflows()) return;
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'taliri-desc-toggle';
    var more = fr ? 'Voir plus' : 'Read more';
    var less = fr ? 'Voir moins' : 'Read less';
    btn.textContent = more;
    btn.addEventListener('click', function () {
      var open = desc.classList.toggle('is-open');
      btn.classList.toggle('is-open', open);
      btn.textContent = open ? less : more;
    });
    desc.parentNode.insertBefore(btn, desc.nextSibling);
  }
  if (document.readyState === 'complete') init();
  else window.addEventListener('load', init);
})();


/* product gallery: auto-advance the photos after a few seconds of
   inactivity; any interaction (touch, wheel, manual scroll, key) pauses it
   and re-arms the idle timer. Mobile slider only, skipped for
   prefers-reduced-motion, and only while the gallery is on screen. */
(function () {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var slider = document.querySelector('.product__media-wrapper .product__media-list');
  if (!slider) return;
  var items = slider.querySelectorAll('.product__media-item');
  if (items.length < 2) return;
  var mq = window.matchMedia('(max-width: 749px)');
  var IDLE_MS = 5000;
  var STEP_MS = 5000;
  var idleTimer = null;
  var stepTimer = null;
  var autoScrolling = false;

  function inView() {
    var r = slider.getBoundingClientRect();
    return r.bottom > 80 && r.top < (window.innerHeight || document.documentElement.clientHeight) - 80;
  }
  function advance() {
    if (!mq.matches || !inView() || document.hidden) return;
    var w = slider.clientWidth || 1;
    var idx = Math.round(slider.scrollLeft / w);
    var next = (idx + 1) % items.length;
    autoScrolling = true;
    slider.scrollTo({ left: next * w, behavior: 'smooth' });
    setTimeout(function () {
      autoScrolling = false;
    }, 800);
  }
  function stopAuto() {
    if (stepTimer) {
      clearInterval(stepTimer);
      stepTimer = null;
    }
  }
  function poke() {
    stopAuto();
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(function () {
      stopAuto();
      stepTimer = setInterval(advance, STEP_MS);
    }, IDLE_MS);
  }
  ['touchstart', 'pointerdown', 'wheel', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, poke, { passive: true });
  });
  slider.addEventListener(
    'scroll',
    function () {
      if (!autoScrolling) poke();
    },
    { passive: true }
  );
  poke();
})();


/* product page: preselect the best-selling size that is in stock
   (M > L > S > XS > XL); when everything is sold out, XL. Skipped when the
   URL already carries an explicit ?variant= (link shared with a size). */
(function () {
  if (!document.body.classList.contains('template-product')) return;
  if (/[?&]variant=/.test(window.location.search)) return;
  var vs = document.querySelector('variant-selects');
  if (!vs) return;
  var radios = Array.prototype.slice.call(vs.querySelectorAll('input[type="radio"]'));
  if (radios.length < 2) return;
  var names = {};
  radios.forEach(function (r) { names[r.name] = 1; });
  if (Object.keys(names).length > 1) return; // single-option (size) products only

  var order = ['M', 'L', 'S', 'XS', 'XL', 'XXL'];
  var byValue = {};
  radios.forEach(function (r) { byValue[r.value.trim().toUpperCase()] = r; });
  var pick = null;
  for (var i = 0; i < order.length; i++) {
    var r = byValue[order[i]];
    if (r && !r.classList.contains('disabled') && !r.disabled) { pick = r; break; }
  }
  if (!pick) pick = byValue['XL'] || null;
  if (!pick || pick.checked) return;

  // Dawn's product-info / variant-selects scripts are deferred: the change
  // event must fire AFTER they are defined, otherwise the radio looks
  // selected but the form's hidden variant id (and the cart) keep the
  // first variant.
  function apply() {
    pick.checked = true;
    pick.dispatchEvent(new Event('change', { bubbles: true }));
  }
  if (window.customElements && customElements.whenDefined) {
    Promise.all([customElements.whenDefined('variant-selects'), customElements.whenDefined('product-info')])
      .then(function () { requestAnimationFrame(apply); })
      .catch(apply);
  } else {
    window.addEventListener('load', apply);
  }
})();
