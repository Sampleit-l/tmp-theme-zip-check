# Atelier Streetwear — thème Shopify

Thème Shopify basé sur Dawn (Shopify, licence MIT — voir `LICENSE.md`), enrichi d'un ensemble de fonctionnalités streetwear / e-commerce mobile-first. Livré **vierge** : aucune image, aucun texte de marque, aucune police sous licence. Tout se règle dans l'éditeur de thème.

## Installation

1. Shopify admin → Boutique en ligne → Thèmes → **Ajouter un thème → Importer un fichier zip**.
2. Éditeur de thème → Paramètres du thème : logo, favicon, polices (titres / texte), couleurs.
3. Créer les **métachamps produit** listés plus bas (pour « Complete the look », les coloris liés, le bandeau mannequin).
4. Page d'accueil : choisir l'image/vidéo du hero, la collection « Nouveautés », les 3 collections du showcase.
5. Fiche produit : choisir la collection de la section « You may also like ».
6. Menus : le header attend un menu `main-menu`, le footer un menu `footer` (modifiables dans les sections).

## Fonctionnalités

### Page d'accueil
- **Atelier Hero** : image **ou** vidéo, médias séparés desktop / mobile, hauteur naturelle du média, navbar transparente en mode « différence » par-dessus, H1 SEO invisible (EN/FR).
- **Collection showcase** : accordéon de 3 collections piloté par le scroll, images pleine largeur.
- **Atelier Promo bar** : bannière fixe en haut du site (texte EN/FR, lien, couleurs, interrupteur).
- Cartes produit : slider de photos, badge « Sale » en mode fusion, ajout rapide avec feuille de tailles (mobile).

### Fiche produit
- Galerie plein écran sur mobile, photos collées, **auto-défilement** après 5 s d'inactivité.
- **Coloris liés** : vignettes photo sous le prix vers les autres coloris (pages produit séparées).
- Tailles présélectionnées sur la taille la plus vendue disponible (M > L > S > XS > XL).
- **Trouver ma taille** : taille + poids → recommandation en pourcentage.
- Ligne « Commande maintenant et reçois le … » (J + délai réglable).
- Bouton d'achat noir avec prix (et prix barré en promo), barre sticky avec dropdowns taille / coloris.
- Badges de paiement sécurisé, lignes de réassurance, description repliée (3 lignes + « Read more »).
- **Complete the look** : produits associés avec ajout direct au panier.
- **Bandeau mannequin** sous la galerie (« Le modèle mesure 180 cm et porte du M »), affiché seulement si renseigné.
- Badge promo pulsé (texte réglable), **You may also like** en carrousel de toute une collection avec ligne de progression.

### Panier (drawer + page)
- **Jauge de livraison offerte** (seuil réglable) qui passe au vert.
- Cartes produit compactes (photo alignée, quantité intégrée), prix barré + économies en vert, récap « Total initial / Économies / Total ».
- **Complete your look** : suggestions basées sur le contenu du panier (métachamps), ajout via feuille de tailles.
- Bandeau de réassurance, badges de paiement sous le checkout.

### Page mot de passe (coming soon)
Vidéo en fond, logo en mode fusion, compte à rebours, capture email + téléphone avec indicatif pays (~200 pays), consentement SMS (le numéro est enregistré **en tag** `phone:+33…` sur la fiche client : le formulaire client Shopify n'accepte que l'email), bouton « ajouter un rappel » (.ics iPhone / Google Agenda).

### International
Tous les textes custom sont bilingues **EN / FR** (détection de la langue de la boutique). Redirection automatique une seule fois vers la langue du navigateur.

## Réglages du thème (Paramètres du thème → « Atelier — boutique »)
| Réglage | Rôle | Défaut |
|---|---|---|
| Seuil livraison offerte | jauge du panier | 50 |
| Délai de livraison estimé | ligne « reçois le … » (jours ouvrés) | 5 |
| Texte du badge promo | badge sur les fiches produit (vide = « Sale ») | — |

## Métachamps produit à créer (Paramètres → Données personnalisées → Produits)
Tous avec **accès Storefront activé** (sinon le thème ne les lit pas).

| Nom | Espace de noms / clé | Type | Usage |
|---|---|---|---|
| Produits associés | `custom.matching_products` | Liste de produits | Complete the look (fiche + panier) |
| Produit associé | `custom.matching_product` | Produit | ancien format, un seul produit (secours) |
| Coloris liés | `custom.color_variants` | Liste de produits | vignettes des autres coloris |
| Mannequin — prénom | `custom.model_name` | Texte | bandeau mannequin (optionnel) |
| Mannequin — taille (cm) | `custom.model_height` | Entier | bandeau mannequin |
| Mannequin — taille portée | `custom.model_size` | Texte | bandeau mannequin |

## Fichiers clés
- `assets/custom.css` — toute la couche design.
- `assets/taliri-card-slider.js` — header transparent, sliders, barre sticky, feuille de tailles, auto-défilement, présélection taille, description repliée.
- `sections/taliri-*.liquid` — hero, mot de passe, promo bar, « you may also like ».
- `snippets/` — `complete-look*`, `color-links`, `size-finder`, `delivery-estimate`, `product-perks`, `payment-badges`, `model-info`, `cart-*`.

Les préfixes `taliri-` dans les classes CSS / fichiers sont des identifiants internes, sans effet visible.

## Notes
- Le texte « Sale » des cartes est volontairement en anglais dans toutes les langues (modifiable dans `snippets/card-product.liquid`).
- Les polices de titres sont celles du sélecteur de polices Shopify (aucune police embarquée).
